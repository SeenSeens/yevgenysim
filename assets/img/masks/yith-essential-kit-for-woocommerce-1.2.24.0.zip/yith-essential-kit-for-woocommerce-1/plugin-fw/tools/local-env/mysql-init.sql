/**
 * MySQL server init.
 *
 * SQL queries in this file will be executed the first time the MySQL server is started.
 */

CREATE DATABASE IF NOT EXISTS yith_plugin_fw_tests;
